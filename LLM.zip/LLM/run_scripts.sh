

# for model in "chatgpt" "llama2-13b"
# do 
#     for k in 1 3
#     do 
#         for n in 5 10 
#         do 
#             for n_prime in 2 3 4 
#             do 
#                 for model2 in "google/flan-t5-large"
#                 do 
#                     python sst2.py --predict_only T --model $model --model2 $model2 --N 100 --n $n --n_prime $n_prime --k $k
#                     echo "$model $model2 $N $n $n_prime $k Finished"
#                 done
#             done 
#         done 

#     done
# done 


#python sst2.py --predict_only T --model chatgpt --model2 google/flan-t5-large --N all --n 5 --n_prime 2 --k 3

#python sst2.py --predict_only T --model llama2-13b --N all --n 5 --n_prime 2 --k 3

for model in "chatgpt" "llama2-13b":
do 
    for k in 5 10 15 20
    do 
        python sst2.py --generate_only T --model $model --N 100 --n 5 --n_prime 2 --k $k
    done 
done
