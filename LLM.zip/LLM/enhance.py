import argparse
import nltk
from nltk.corpus import wordnet
import itertools
from random import sample

# nltk.download('punkt')
# nltk.download('words')
# nltk.download('averaged_perceptron_tagger')
# nltk.download('maxent_ne_chunker')
# nltk.download('wordnet')
# nltk.download('omw-1.4')


def generate_sentences(sent, pos_synonyms, ner_synonyms):
    '''
    Generate all possible sentences by replacing words with their synonyms
    '''
    words = nltk.word_tokenize(sent)
    #synonyms = {**pos_synonyms, **ner_synonyms}
    synonyms = {**pos_synonyms}
    #words_with_synonyms = [synonyms.get(word, [word]) for word in words]
    
    words_with_synonyms = []
    for word in words:
        t = synonyms.get(word,[word])
        t = [w.lower() for w in t]
        t = list(set(t))
        if len(t)> 10:
            t = sample(t, 10)

        words_with_synonyms.append(t)

    sentences = list(itertools.product(*words_with_synonyms))
    sentences = [' '.join(sentence) for sentence in sentences]
    #print(len(sentences))
    return sentences

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=str, default='He comes from a very big China.')
    args = parser.parse_args()
    return args

def parse_by_POS(sent):
    '''
    parse adjective, adverb, and noun
    '''
    #https://cs.nyu.edu/~grishman/jet/guide/PennPOS.html
    # ['JJ', 'RB', 'NN', 'NNS', 'NNP','VB','VBD','VBG','VBN','VBP','VBZ']
    l = ['JJ', 'RB', 'NN', 'NNS', 'NNP']
    pos_list = nltk.pos_tag(nltk.word_tokenize(sent))
    pos_list = [pos for pos in pos_list if pos[1] in l] 
    return pos_list[:5]

def parse_by_NER(sent):
    '''
    parse person name and contry name
    '''
    ner_tree = nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(sent)))
    ner_list = nltk.chunk.tree2conlltags(ner_tree)
    # ner_list = [ner for ner in ner_list if ner[2] in ['B-PERSON', 'I-PERSON', 'B-GPE', 'I-GPE']]
    ner_list = [ner for ner in ner_list if ner[2] in ['B-GPE', 'I-GPE']]
    return ner_list

def get_synonyms(word):
    '''
    get synonyms of the input word
    '''
    synonyms = []
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.append(lemma.name())
    return synonyms

def main():
    args = parse_args()
    sent = args.input
    pos_list = parse_by_POS(sent)
    ner_list = parse_by_NER(sent)
    print ('Original sentence:')
    print(sent)
    print ()

    pos_synonyms = {word: get_synonyms(word) for word, _ in pos_list}
    ner_synonyms = {word: get_synonyms(word) for word, _, _ in ner_list}

    # print ("POS list and their synonyms:", pos_synonyms)
    # print ("NER list and their synonyms:", ner_synonyms)

    all_sentences = generate_sentences(sent, pos_synonyms, ner_synonyms)
    print("All possible sentences:")
    print(all_sentences)

    st, res = set(), []
    for sentence in all_sentences:
        sentence = sentence.replace('_', ' ')
        if sentence.lower() not in st:
            res.append([sentence])
            st.add(sentence)
            print(sentence)
    
    # print (res)
    return res


if __name__ == '__main__':
    main()
