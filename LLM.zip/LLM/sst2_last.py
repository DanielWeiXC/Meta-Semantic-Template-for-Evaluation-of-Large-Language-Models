import torch
import time
from rewrite import *
from predict import *
from enhance import *
from datasets import load_dataset
import pickle
from random import sample, choice
import nltk
import os


def parse_args():
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--gen_new_sent', type=bool, default=False) # the test dataset

    parser.add_argument('--dataset', type=str, default="sst2") # the test dataset
    parser.add_argument('--n', type=int, default=5) # how many sentences to generate
    # parser.add_argument('--n', type=int, default=10) # how many sentences to generate

    parser.add_argument('--n_prime', type=int, default=2) # how many sentences to keep after filtering
    # parser.add_argument('--n_prime', type=int, default=5) # how many sentences to keep after filtering

    parser.add_argument('--k', type=int, default=5) # how many sentences to have for one new template
    # parser.add_argument('--model', type=str, default="llama2-13b") # the generation model
    parser.add_argument('--model', type=str, default="chatgpt") # the generation model

    parser.add_argument('--model2', type=str, default="chatgpt") # the prediction model #default llama2 is 7b
    # parser.add_argument('--model2', type=str, default="llama2") # the prediction model #default llama2 is 7b

    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--predict_only', type= bool, default = False) 
    parser.add_argument('--generate_only', type= bool, default = False) 
    parser.add_argument('--N', type=str, default='3') # "all" or a number -- number of items in the original testset to test
    # parser.add_argument('--N', type=str, default='100') # "all" or a number -- number of items in the original testset to test
    # parser.add_argument('--predict_only', type=str, default='100')

    args = parser.parse_args()
    return args

def download_nltk():
    import nltk
    nltk.download('punkt')
    nltk.download('averaged_perceptron_tagger')
    nltk.download('maxent_ne_chunker')
    nltk.download('words')
    nltk.download('wordnet')
    
def get_N(args_N, test_dataset):
    if args_N.isdigit():
        N = int(args_N)
        if N> len(test_dataset):
            N= len(test_dataset)
    elif args_N.lower() == "all":
        N =len(test_dataset)
    else:
        raise Exception("This args.N is not allowed")
    return N
    

def main():

    t = time.time()
    #download_nltk() 
    args = parse_args()
    
    dataset = load_dataset("glue", args.dataset)
    test_dataset = dataset["validation"]#"train","validation","test"
    actual_labels = [test_dataset[i]["label"] for i in range(len(test_dataset))]
    
    N = get_N(args.N, test_dataset)

    if args.predict_only == False:
        t1 = time.time()
        
        
        
        #################### sentences after filter #############################
        new_sent_total, new_label = [], []
        
        new_sent_total_path = f'new_sent_total/{args.dataset}/{args.model}/sentences_{N}_{args.n}_{args.n_prime}_{args.k}.pkl'
        new_label_path = f'new_label/{args.dataset}/{args.model}/labels_{N}_{args.n}_{args.n_prime}_{args.k}.pkl'
        
        
        #################### sentences before filter #############################
        new_sent_total_raw, new_label_raw = [], []
        
        new_sent_total_raw_path = f'new_sent_label_raw/new_sent_total_raw/{args.dataset}/{args.model}/sentences_{N}_{args.n}_.pkl'
        new_label_raw_path = f'new_sent_label_raw/new_label_raw/{args.dataset}/{args.model}/labels_{N}_{args.n}_.pkl'
        
        find_raw_sent = 0
        the_root_path_list = []
        
        for i,j,k in os.walk(f'new_sent_label_raw/new_sent_total_raw/{args.dataset}/{args.model}/'):
            for file in k:
                if file.endswith('.pkl'):
                    the_path = os.path.join(i,file)
                    the_path_N = int(the_path[len(f'new_sent_label_raw/new_sent_total_raw/{args.dataset}/{args.model}/'):].split('_')[1])
                    arg_n = int(the_path[len(f'new_sent_label_raw/new_sent_total_raw/{args.dataset}/{args.model}/'):].split('_')[2])
                    if the_path_N >= N and arg_n >= args.n:
                        find_raw_sent = 1
                        the_root_path_list.append(the_path)
                        
                        
                        
        #################### start filter ############################
        if find_raw_sent == 1 and args.gen_new_sent == False:
            the_path_root_sent = choice(the_root_path_list)
            the_path_root_label = f'new_sent_label_raw/new_label_raw/{args.dataset}/{args.model}/labels_{the_path_N}_{arg_n}_.pkl'
            print("find the raw sentences file: " + the_path_root_sent +  ". Start filter")

            with open(the_path_root_sent, 'rb') as file:
                new_sent_total_raw = pickle.load(file)
            with open(the_path_root_label, 'rb') as file:
                new_label_raw = pickle.load(file)
            assert len(new_sent_total_raw) == len(new_label_raw), "The generated sentences and labels are not of the same length.."
            
            t2 = time.time()
            for i in range(N):
                seed_s = test_dataset[i]["sentence"]
                # filter
                new_sentences = sentence_filter(seed_s, new_sent_total_raw[i], args.n_prime)

                new_sent_total.extend(new_sentences)
                new_label.extend([test_dataset[i]["label"]] * len(new_sentences))

            assert len(new_sent_total) == len(new_label), "length of sentences and labels are not the same after rewriting."
            assert len(new_sent_total_raw) == len(new_label_raw)

            t3 = time.time()
            print("Filter", N, "seeds sentences uses", t3 - t2)
            print("Filter gives new sentences: ", len(new_sent_total))

            #################### save to file ############################

            with open(new_sent_total_path, 'wb') as file:
                pickle.dump(new_sent_total, file)
            with open(new_label_path, 'wb') as file:
                pickle.dump(new_label, file)
                
                
        #################### start generation ############################
        else:
            print("Not find the raw sentences file, start generation")
            if "chatgpt" in args.model:
                t2 = time.time()
                for i in range(N):
                    print("i = ", i)
                    seed_s = test_dataset[i]["sentence"]
                    prompt = make_generation_prompt(seed_s, args.n)
                    new_sentences = chatgpt(prompt)

                    # print(new_sentences)
                    new_sent_total_raw.append(new_sentences)
                    new_label_raw.append([test_dataset[i]["label"]] * len(new_sentences))

                    # filter
                    new_sentences = sentence_filter(seed_s, new_sentences, args.n_prime)

                    new_sent_total.extend(new_sentences)
                    new_label.extend([test_dataset[i]["label"]] * len(new_sentences))

                    if i % 10 == 0:  # Check if it's the 10th iteration
                        # print(f"Pausing for 30 seconds after the {i}th sample in {args.dataset}...")
                        time.sleep(30)


            else:  ## the generation model is not chatgpt
                tokenizer, pipe = create_model(args.model, device=args.device)
                t2 = time.time()
                print(f"Generation model loading uses {t2 - t1} seconds")

                for i in range(N):
                    seed_s = test_dataset[i]["sentence"]
                    new_sentences = generate(args.model, tokenizer, pipe, args.n, seed_s, args.device)

                    # print(new_sentences)
                    new_sent_total_raw.append(new_sentences)
                    new_label_raw.append([test_dataset[i]["label"]] * len(new_sentences))

                    # filter
                    new_sentences = sentence_filter(seed_s, new_sentences, args.n_prime)

                    new_sent_total.extend(new_sentences)
                    new_label.extend([test_dataset[i]["label"]] * len(new_sentences))
                           
            assert len(new_sent_total) == len(new_label), "length of sentences and labels are not the same after rewriting."
            assert len(new_sent_total_raw) == len(new_label_raw)

            t3 = time.time()
            print("Rewriting", N, "seeds sentences uses", t3 - t2)
            print("Rewriting gives new sentences: ", len(new_sent_total))

            #################### save to file ############################
            # new_sent_total_path = f'new_sent_total/{args.dataset}/{args.model}/sentences_{N}_{args.n}_{args.n_prime}_{args.k}.pkl'
            # new_label_path = f'new_label/{args.dataset}/{args.model}/labels_{N}_{args.n}_{args.n_prime}_{args.k}.pkl'
            with open(new_sent_total_raw_path, 'wb') as file:
                pickle.dump(new_sent_total_raw, file)
            with open(new_label_raw_path, 'wb') as file:
                pickle.dump(new_label_raw, file)

            with open(new_sent_total_path, 'wb') as file:
                pickle.dump(new_sent_total, file)
            with open(new_label_path, 'wb') as file:
                pickle.dump(new_label, file)
                
            print(new_sent_total)
                
         

        #################### Parsing + Enhance #############################
        print("Now start parsing and enhancing...")
        if args.k ==1 :
            n_k_sentences, new_label_final = new_sent_total, new_label
        else: 
            n_k_sentences, new_label_final = [], []  
            for idx, sent in enumerate(new_sent_total):
                # print(idx)
                n_k_sentences.extend([sent])
                pos_list = parse_by_POS(sent)
                pos_synonyms = {word: get_synonyms(word) for word, _ in pos_list}
                # print('pass1')
                all_sentences = generate_sentences(sent, pos_synonyms, {})
                st, res = set(), []
                # print('pass2')
                for sentence in all_sentences:
                    sentence = sentence.replace('_', ' ')
                    if sentence.lower() not in st and len(sentence)>=8:
                        res.append(sentence)
                        st.add(sentence)
                if len(res) >args.k-1:                              
                    n_k_sentences.extend(sample(res,(args.k-1)))
                    new_label_final.extend([new_label[idx]]*args.k)
                else:
                    n_k_sentences.extend(res)
                    new_label_final.extend([new_label[idx]]*(len(res)+1))

        t4 = time.time()
        print("Parsing and enhansing uses", t4-t3)
        print(f'Total {len(n_k_sentences)} new sentences after expanding the template.')

        
        assert len(n_k_sentences) == len(new_label_final), "The total generated sentences and labels are not of the same length.."
        ######## save to file ############################
        s_file_path = f'new_data/{args.dataset}/{args.model}/sentences_{N}_{args.n}_{args.n_prime}_{args.k}.pkl'
        label_file_path = f'new_data/{args.dataset}/{args.model}/labels_{N}_{args.n}_{args.n_prime}_{args.k}.pkl'
        with open(s_file_path, 'wb') as file:
            pickle.dump(n_k_sentences, file)        
        with open(label_file_path, 'wb') as file:
            pickle.dump(new_label_final, file)
    

    else: #predict_only == True
        pass
    
    if args.generate_only == False: 
        ######## Starting Prediction #####################
        t5 = time.time()

        s_file_path = f'new_data/{args.dataset}/{args.model}/sentences_{N}_{args.n}_{args.n_prime}_{args.k}.pkl'
        label_file_path = f'new_data/{args.dataset}/{args.model}/labels_{N}_{args.n}_{args.n_prime}_{args.k}.pkl'

        with open(s_file_path, 'rb') as file:
            new_test_sentences = pickle.load(file)
        with open(label_file_path, 'rb') as file:
            actual_new_labels = pickle.load(file)
        assert len(new_test_sentences) == len(actual_new_labels), "The generated sentences and labels are not of the same length.."

        if "chatgpt" in args.model2:  
            t6 = time.time()
            print("Create prediction model takes, ", t6-t5)
            openai.api_key = 'sk-proj-2el6Un91wyIipmnNJAjmT3BlbkFJoqQIG1GVyJHgqy4gG7JE'
            predicted = []
            
            for sentence in new_test_sentences:
                response = openai.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "system", "content": "Imagine you are an AI model engaged in a binary sentiment analysis task. Your mission is to accurately classify sentences from the SST2 dataset into one of two categories: 'positive' or 'negative'. Return the appropriate sentiment label for the following sentence in one word. "},
                            {"role": "user", "content": f"Classify the sentiment of the following sentence as 'positive' or 'negative':\n\n{sentence}\n\nAnswer: "}
                    ], 
                    max_tokens=40,  
                    temperature=0  
                )
                choices = response.choices
                chat_completion = choices[0]
                content = chat_completion.message.content
                predicted.append(extract_label("ChatGPT", content))
                
            acc = calculate_accuracy(predicted, actual_new_labels)
            print("accuracy of GPT-3.5 is", acc)
            t7 = time.time()
            print("Total time for prediction and accuracy calculation:", t7 - t6)
            model2 = "ChatGPT" 
            
        else:
            tokenizer, pipe = create_model(args.model2, args.device)
            t6 = time.time()
            print("Create prediction model takes, ", t6-t5)

            predicted = predict(args.model2, tokenizer, pipe, new_test_sentences, args.device)
            acc = calculate_accuracy(predicted,actual_new_labels)
            print("accuracy of ", args.model2, "is", acc)
            t7 = time.time()
            model2 = args.model2.replace("/","_")
            

        file_path = f'results/template_results/{args.dataset}/{args.model}/{model2}_{N}_{args.n}_{args.n_prime}_{args.k}.txt'
        with open(file_path, 'w') as file:
            if args.predict_only == False:
                file.write(f"The generation model is {args.model}")
                file.write(f"\nn = {args.n} ,\nn_prime = {args.n_prime},\nk = {args.k}, \nN = {N}")
            else: 
                file.write("Predict Only...")

            file.write(f"\nThere are {len(new_test_sentences)} new sentences after template expanding.")
            file.write(f"\nThere are {len(actual_new_labels)} new labels after template expanding." )

            file.write(f'\nThe prediction model is {args.model2}')
            file.write(f'\nAnd the accuracy is {acc}.')

            file.write(f'\n\nThe first seed sentence is {test_dataset[0]["sentence"]} with label {test_dataset[0]["label"]}.')
            file.write(f'\nThe generated sentences are {new_test_sentences[:args.n_prime*args.k]}')
            file.write(f'\nThe corresponding true labels are {actual_new_labels[:args.n_prime*args.k]}')
            file.write(f'\nThe predicted labels are {predicted[:args.n_prime*args.k]}')

            file.write(f'\n\nTotal Time {t7-t} seconds = {(t7-t)/60} min =  {(t7-t)/3660} hours')
            file.write(f'\nGeneration model loading uses {t2-t1}')
            file.write(f'\nRewriting uses {t3-t2}' )
            file.write(f'\nParsing and enhansing uses {t4-t3}')
            file.write(f'\nCreate prediction model takes {t6-t5}')
            file.write(f'\nMaking predictions uses {t7-t6}' )
        
        
    


if __name__ == '__main__':
    main()
