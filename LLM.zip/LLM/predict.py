from rewrite import create_model
import argparse 

def get_label(model_str, tokenizer, pipe, sent, device):
    '''
    helper for predict function
    '''
    input_text = sent
    input_ids = tokenizer(input_text, return_tensors="pt").input_ids.to(device)
    if model_str  == "google/flan-t5-large":
        outputs = pipe.generate(input_ids, max_length=3, early_stopping=True)
        out = tokenizer.decode(outputs[0])
    elif model_str == "google/flan-ul2":
        outputs = pipe.generate(input_ids, max_length=3, early_stopping=True)
        out = tokenizer.decode(outputs[0])
    elif model_str == "llama" or model_str == "llama-13b":
        outputs = pipe.generate(input_ids, temperature=0.1, max_new_tokens=3, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "llama2" or model_str.lower() == "llama2-13b" or model_str.lower() == "llama2-7b":
        outputs = pipe.generate(input_ids, temperature=0.1, top_p = 0.1, max_new_tokens=30, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "vicuna-13b":
        outputs = pipe.generate(input_ids, temperature=0.1, max_new_tokens=3, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "databricks/dolly-v1-6b":
        outputs = pipe.generate(input_ids, pad_token_id = tokenizer.eos_token_id, temperature=0.1, max_new_tokens=3, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "cerebras/Cerebras-GPT-13B":
        outputs = pipe.generate(input_ids, pad_token_id = tokenizer.eos_token_id, temperature=0.1, max_new_tokens=3, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "phi-2":
        outputs = pipe.generate(input_ids, max_new_tokens=30)
        out = tokenizer.batch_decode(outputs)[0]
    elif model_str == "gemma-7b-it":
        outputs = pipe.generate(input_ids, max_new_tokens=30)
        out = tokenizer.decode(outputs[0])
    else:
        print("not implemented")
    #print(out)
    print(out)

    return extract_label(model_str, out)

def extract_label(model_str, p):
    if "google" in model_str:
        if "negative" in p:
            l = 0
        elif "positive" in p:
            l = 1
        else:
            l = -1
    else:
        if "negative" in p.lower()[-15:]:
            l = 0
        elif "positive" in p.lower()[-15:]:
            l = 1
        else:
            l = -1    
    return l

def predict(model_str,tokenizer, pipe, sent_list, device):
    predicted_labels = []
    for sent in sent_list:
        predicted_labels.append(get_label(model_str, tokenizer, pipe, sent, device))
    return predicted_labels

def calculate_accuracy(predicted_labels, actual_labels):
        # Calculate accuracy
        print(len(predicted_labels),len(actual_labels))
        assert len(predicted_labels) == len(actual_labels), print("predicted_labels and actual_labels are not of the same length.")
        correct_predictions = sum(1 for pred, actual in zip(predicted_labels, actual_labels) if pred == actual)
        total_predictions = len(predicted_labels)
        accuracy = correct_predictions / total_predictions
        return accuracy

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed_sentence', type=str, default="I used to think this is good but now I think it is bad")
    parser.add_argument('--n', type=int, default=10) ### how many sentences to generate 
    parser.add_argument('--k', type=int, default=5) ### 
    parser.add_argument('--model', type=str, default="llama2")
    parser.add_argument('--device',type = int, default = 1)
    parser.add_argument('--model2', type=str, default="llama2")
    args = parser.parse_args()
    return args



def main():
    args = parse_args()
    model_str = args.model2
    tokenizer,pipe = create_model(model_str, args.device)

    # sent_list and actual_labels will be read from files.
    sent_list = ['you are good', 'sunny day!', 'Please leave me alone']
    actual_labels = [1,1,0]
    
    acc = predict(model_str,tokenizer,pipe, sent_list, actual_labels, args.device)
    print("accuracy of ", model_str, "is" , acc)


    


if __name__ == '__main__':
    main()






