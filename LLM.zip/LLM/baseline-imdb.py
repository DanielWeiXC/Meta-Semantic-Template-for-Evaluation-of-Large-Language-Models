import torch
import time
from rewrite import *
from predict import *
from enhance import *
from datasets import load_dataset
import pickle
import random
import nltk
import zipfile
import os
from datasets import load_from_disk

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model2', type=str, default="llama2") # the prediction model
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--dataset',type=str, default = "sst2") #which glue dataset?
    parser.add_argument('--N', type=str, default="all")
    args = parser.parse_args()
    return args

def get_N(args_N, test_dataset):
    if args_N.isdigit():
        N = int(args_N)
        if N> len(test_dataset):
            N= len(test_dataset)
    elif args_N.lower() == "all":
        N =len(test_dataset)
    else:
        raise Exception("This args.N is not allowed")
    return N

def main():
    args = parse_args()
    
    with zipfile.ZipFile('amazon_sample.zip', 'r') as zip_ref:
        zip_ref.extractall('datasets')
    
    dataset =load_from_disk('datasets')
    test_dataset = dataset["train"].shuffle(seed=42)#"train","validation","test"
        
    N = get_N(args.N, test_dataset)
    actual_labels = [test_dataset[i]["label"] for i in range(len(test_dataset))][:N]
    sentence_list = [test_dataset[i]["text"] for i in range(len(test_dataset))][:N]
    if "chatgpt" in args.model2:  
            t1 = time.time()
            openai.api_key = 'sk-proj-2el6Un91wyIipmnNJAjmT3BlbkFJoqQIG1GVyJHgqy4gG7JE'
            predicted = []
            t2 = time.time()
            for sentence in sentence_list:
                response = openai.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "system", "content": "Imagine you are an AI model engaged in a binary sentiment analysis task. Your mission is to accurately classify sentences from the SST2 dataset into one of two categories: 'positive' or 'negative'. Return the appropriate sentiment label for the following sentence in one word. "},
                            {"role": "user", "content": f"Classify the sentiment of the following sentence as 'positive' or 'negative':\n\n{sentence}\n\nAnswer: "}
                    ], 
                    max_tokens=40,  
                    temperature=0  
                )
                choices = response.choices
                chat_completion = choices[0]
                content = chat_completion.message.content
                predicted.append(extract_label("ChatGPT", content))
                
            acc = calculate_accuracy(predicted, actual_labels)
            print("accuracy of GPT-3.5 is", acc)
            t3 = time.time()
            print("Total time for prediction and accuracy calculation:", t3 - t2)
    else: 
        t1 = time.time()
        tokenizer, pipe = create_model(args.model2, args.device)
        t2 = time.time()
        print("Create prediction model takes, ", t2-t1)

        predicted = predict(args.model2, tokenizer, pipe, sentence_list, args.device)
        print("predicted labels", predicted)
        acc = calculate_accuracy(predicted,actual_labels)
        print("Accuracy of ", args.model2, "is", acc)
        t3 = time.time()
        print("Prediction takes", t3-t2)
     
    model2 = args.model2.replace("/","_")
    file_path = f'results/baseline_results/{args.dataset}/{args.model2}/{model2}_{args.N}.txt'
    with open(file_path, 'w') as file:
        file.write(f'BASELINE: The dataset is {args.dataset} with {len(test_dataset)} sentences.')
        file.write(f'\nThe prediction model is {args.model2}')
        file.write(f'\nAnd the accuracy is {acc}.')
        file.write(f'\nTotal Time is {t3-t2}.')


if __name__ == '__main__':
    main()
