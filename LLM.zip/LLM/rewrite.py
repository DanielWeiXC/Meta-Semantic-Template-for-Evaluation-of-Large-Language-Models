## 1 2 rewrite and sentence_filter

## Input: one seed sentence
## Output: n sentences
## rewrite the seed sentence using A model 
## MODEL_SET: all possible language models that could rewrite the sentence given a prompt.
## args : prompt_rewrite, model, seed_sentence, n 
import argparse
import torch
import re
from transformers import AutoTokenizer, AutoModel
from sklearn.metrics.pairwise import cosine_similarity
import os
import openai


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed_sentence', type=str, default="I used to think this is good but now I think it is bad")
    parser.add_argument('--n', type=int, default=10)
    parser.add_argument('--n_prime', type=int, default=5)
    parser.add_argument('--model', type=str, default="llama2")
    
    args = parser.parse_args()
    return args

def create_model(model_str, device):
    if "t5" in model_str:
        from transformers import T5Tokenizer, T5ForConditionalGeneration
        tokenizer = T5Tokenizer.from_pretrained(model_str)
        pipe = T5ForConditionalGeneration.from_pretrained(model_str).to(device)
        
    elif model_str  == "google/flan-t5-large":
        from transformers import T5Tokenizer, T5ForConditionalGeneration
        tokenizer = T5Tokenizer.from_pretrained(model_str)
        pipe = T5ForConditionalGeneration.from_pretrained(model_str).to(device)
        
    elif model_str == "google/flan-ul2":
        from transformers import T5ForConditionalGeneration, AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(model_str)
        pipe = T5ForConditionalGeneration.from_pretrained(model_str, torch_dtype=torch.bfloat16).to(device)  
        
    elif model_str == "llama-13b":
        from transformers import LlamaForCausalLM, LlamaTokenizer
        model_dir = os.path.join("/home/v-yachuanliu/codedirs/llms", "llama-13b")
        tokenizer = LlamaTokenizer.from_pretrained(model_dir, device_map="auto")
        pipe = LlamaForCausalLM.from_pretrained(model_dir, torch_dtype=torch.float16).to(device)
    
    elif model_str.lower() == "llama2" or "llama2-7b":
        from transformers import LlamaForCausalLM, LlamaTokenizer
        model_dir = "meta-llama/Llama-2-7b-chat-hf"
        tokenizer = LlamaTokenizer.from_pretrained(model_dir, device_map="auto")
        pipe = LlamaForCausalLM.from_pretrained(model_dir, torch_dtype=torch.float16).to(device)
        
    elif model_str.lower() == "llama2-13b" :
        from transformers import LlamaForCausalLM, LlamaTokenizer
        model_dir = "meta-llama/Llama-2-13b-chat-hf"
        tokenizer = LlamaTokenizer.from_pretrained(model_dir, device_map="auto")
        pipe = LlamaForCausalLM.from_pretrained(model_dir, torch_dtype=torch.float16).to(device)
        
    elif model_str.lower() == "vicuna-13b":
        from transformers import AutoModelForCausalLM, AutoTokenizer
        model_dir = os.path.join("/home/v-yachuanliu/codedirs/llms", "vicuna-13b")
        tokenizer = AutoTokenizer.from_pretrained(model_dir, device_map="auto", use_fast=False)
        pipe = AutoModelForCausalLM.from_pretrained(model_dir, torch_dtype=torch.float16).to(device)
    
    elif model_str == "databricks/dolly-v1-6b":
        from transformers import AutoModelForCausalLM, AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(model_str, device_map="auto", padding_side="left")
        pipe = AutoModelForCausalLM.from_pretrained(model_str, torch_dtype=torch.float16).to(device)
    
    elif model_str == "cerebras/Cerebras-GPT-13B":
        from transformers import AutoTokenizer, AutoModelForCausalLM
        tokenizer = AutoTokenizer.from_pretrained(model_str, device_map="auto")
        pipe = AutoModelForCausalLM.from_pretrained(model_str, torch_dtype=torch.float16).to(device)
    elif model_str == "phi-2":
        from transformers import LlamaForCausalLM, LlamaTokenizer
        model_dir = "microsoft/phi-2"
        tokenizer = AutoModelForCausalLM.from_pretrained(model_dir, torch_dtype="auto", trust_remote_code=True)
        pipe = AutoTokenizer.from_pretrained(model_dir, trust_remote_code=True).to(device)
    elif model_str == "gemma-7b-it":
        from transformers import LlamaForCausalLM, LlamaTokenizer
        tokenizer = AutoTokenizer.from_pretrained("google/gemma-7b-it")
        pipe = AutoModelForCausalLM.from_pretrained("google/gemma-7b-it", device_map="auto")
        
    else:
        print("This Model is Not Implemented")
    return tokenizer,pipe

def make_generation_prompt(s, n):
    prompt = ("Could you generate " + str(n) 
                + "paragraph that (1) of different sentence structures and (2) of the same meaning with the following sentence: \""
                + s # need n
                + "\". Please number the generated sentences from 1 to "+ str(n)+"."
                )
    return prompt

def generate(model_str, tokenizer, pipe, n, s, device):
    prompt = make_generation_prompt(s,n)
    input_text = prompt
    input_ids = tokenizer(input_text, return_tensors="pt").input_ids.to(device)
    if model_str  == "google/flan-t5-large":
        outputs = pipe.generate(input_ids, max_length=50, early_stopping=True)
        out = tokenizer.decode(outputs[0])
    elif model_str == "google/flan-ul2":
        outputs = pipe.generate(input_ids, max_length=50, early_stopping=True)
        out = tokenizer.decode(outputs[0])
    elif model_str == "llama" or model_str == "llama-13b":
        outputs = pipe.generate(input_ids, temperature=0.5, max_new_tokens=500)#, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "llama2" or model_str == "llama2-13b":
        outputs = pipe.generate(input_ids, temperature=0.5, max_new_tokens=500)#, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "vicuna-13b":
        outputs = pipe.generate(input_ids, temperature=0.5, max_new_tokens=500, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "databricks/dolly-v1-6b":
        outputs = pipe.generate(input_ids, pad_token_id = tokenizer.eos_token_id, temperature=0.5, max_new_tokens=500, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "cerebras/Cerebras-GPT-13B":
        outputs = pipe.generate(input_ids, pad_token_id = tokenizer.eos_token_id, temperature=0.5, max_new_tokens=500, early_stopping=True)
        out = tokenizer.decode(outputs[0], skip_special_tokens=True)
    elif model_str == "phi-2":
        outputs = pipe.generate(input_ids, max_new_tokens=500)
        out = tokenizer.batch_decode(outputs)[0]
    elif model_str == "gemma-7b-it":
        outputs = pipe.generate(input_ids, max_new_tokens=500)
        out = tokenizer.decode(outputs[0])
    else:
        print("not implemented")
    print(out)

    out = extract_numbered_sentences(out)
    if len(out)>n:
        out = out[-n:]
    return out


def extract_numbered_sentences(paragraph):
    # Find all numbered sentences using regular expression
    paragraphs = re.split(r'\d+\.\s', paragraph)[1:]
    paragraphs = [para.strip() for para in paragraphs if para.strip()]
    return paragraphs


def calculate_similarity(sentence1, sentence2):
    def get_sentence_embedding(sentence):
        model_name = "bert-base-uncased"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModel.from_pretrained(model_name)
        inputs = tokenizer(sentence, return_tensors="pt", padding=True, truncation=True)
        with torch.no_grad():
            outputs = model(**inputs)
            sentence_embedding = torch.mean(outputs.last_hidden_state, dim=1)
        return sentence_embedding
    
    embedding1 = get_sentence_embedding(sentence1)
    embedding2 = get_sentence_embedding(sentence2)
    similarity = cosine_similarity(embedding1, embedding2)
    return similarity

def sentence_filter(seed_s, sent_list, n_prime):
    l = []
    sim = []
    # for s in sent_list:
    #     if calculate_similarity(seed_s,s)[0][0]>=0.5:
    #         l.append(s)
    #         sim.append(calculate_similarity(seed_s,s)[0][0])
    
    l = sent_list
    sim = [calculate_similarity(seed_s,s) for s in sent_list]
    return [x for _, x in sorted(zip(sim, l))][-n_prime:]

def complete_prompt(prompt):
    response = openai.chat.completions.create(
        model='gpt-3.5-turbo',  # Use the GPT-3.5 engine
        messages=[
            {"role": "system", "content": "You will be able to help people rewrite sentence."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=500,  # Adjust the value based on your requirements
        temperature=0,  # Controls the randomness of the output
        n=1,  # Number of responses to generate
        stop=None,  # Stop generating completions at a specific token
        timeout=None,  # Maximum time (in seconds) to wait for a response
    )

    # Extract the first response choice
    completion = response.choices[0].message.content
    return completion

def chatgpt(prompt):
    import openai
    # Set up your OpenAI API key
    api_key = 'sk-proj-2el6Un91wyIipmnNJAjmT3BlbkFJoqQIG1GVyJHgqy4gG7JE'
    openai.api_key = api_key
    # Define the chat completion function
    completion = complete_prompt(prompt)
    return extract_numbered_sentences(completion)

def main(): 
    args = parse_args()

    n = args.n
    seed_s =  args.seed_sentence
    prompt =  ("Could you generate " + str(n) 
    + "sentences that (1) of different sentence structures and (2) of the same meaning with the following sentence: "
    + seed_s # need n
    + ". Please number the generated sentences from 1 to "+ str(n)+"."
    )
    #new_sentences =  generate(args.model, prompt)#list
    device = 0
    
    if "chatgpt" in args.model:
        ###
        new_sentences = chatgpt(prompt)
    else:
        tokenizer, pipe = create_model(args.model, device)
        new_sentences = generate(args.model, tokenizer, pipe, prompt, device)
    new_sentences = sentence_filter(seed_s, new_sentences, args.n_prime)
    print(new_sentences)


if __name__ == '__main__':
    main()